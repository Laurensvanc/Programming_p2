﻿using System;
using System.Collections.Generic;
using System.Text;

namespace assignment1
{
    class Person
    {
        public string name;
        public string city;
        public int age;
    }
}
