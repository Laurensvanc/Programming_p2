﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CandyCrushLogic
{
    public enum RegularCandies
    {
        Jellybean,
        Lozenge,
        LemonDrop,
        Gum_Square,
        LollipopHead,
        Jujube_Cluster
    }
}
